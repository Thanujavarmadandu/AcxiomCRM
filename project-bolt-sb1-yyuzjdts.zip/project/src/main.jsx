import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  Bell,
  CalendarClock,
  ChevronDown,
  CircleDollarSign,
  ClipboardList,
  ContactRound,
  FileBarChart,
  Filter,
  LayoutDashboard,
  LogOut,
  Menu,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Target,
  Users,
  X,
} from 'lucide-react';
import { getProfile, createRecord, updateRecord, loadWorkspace, writeAudit } from './lib/crm';
import { supabase } from './lib/supabase';
import './styles.css';

const navItems = [
  { label: 'Dashboard', icon: LayoutDashboard },
  { label: 'Customers', icon: ContactRound },
  { label: 'Leads', icon: Target },
  { label: 'Opportunities', icon: CircleDollarSign },
  { label: 'Follow-ups', icon: CalendarClock },
  { label: 'Activities', icon: Activity },
  { label: 'Reports', icon: FileBarChart },
];
const adminItems = [{ label: 'Users & Roles', icon: Users }, { label: 'Audit Log', icon: ShieldCheck }];
const emptyWorkspace = { profiles: [], customers: [], leads: [], opportunities: [], follow_ups: [], activities: [], audit_logs: [] };
const friendlyError = 'We could not complete that action. Please check the details and try again.';

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [workspace, setWorkspace] = useState(emptyWorkspace);
  const [authLoading, setAuthLoading] = useState(true);
  const [loading, setLoading] = useState(false);
  const [activePage, setActivePage] = useState('Dashboard');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [period, setPeriod] = useState('This month');
  const [modalType, setModalType] = useState(null);
  const [notice, setNotice] = useState(null);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return;
      setSession(data.session);
      if (data.session) await hydrate(data.session.user.id);
      setAuthLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((event, nextSession) => {
      setSession(nextSession);
      if (nextSession) {
        (async () => {
          await hydrate(nextSession.user.id);
          if (event === 'SIGNED_IN') await writeAudit('login', 'Authentication', null, null, 'User signed in');
        })();
      } else {
        setProfile(null);
        setWorkspace(emptyWorkspace);
      }
    });
    return () => { mounted = false; listener.subscription.unsubscribe(); };
  }, []);

  async function hydrate(userId) {
    try {
      setLoading(true);
      const [nextProfile, nextWorkspace] = await Promise.all([getProfile(userId), loadWorkspace()]);
      if (!nextProfile?.is_active) {
        await supabase.auth.signOut();
        setNotice({ type: 'error', text: 'This account is inactive. Contact an administrator.' });
        return;
      }
      setProfile(nextProfile);
      setWorkspace(nextWorkspace);
    } catch (error) {
      console.error('workspace load failed', error);
      setNotice({ type: 'error', text: 'Your workspace could not be loaded. Please refresh and try again.' });
    } finally {
      setLoading(false);
    }
  }

  async function handleSignOut() {
    await writeAudit('logout', 'Authentication', null, null, 'User signed out');
    await supabase.auth.signOut();
  }

  async function handleCreate(type, values) {
    const table = type === 'follow-up' ? 'follow_ups' : type === 'activity' ? 'activities' : `${type}s`;
    try {
      const record = await createRecord(table, values);
      await writeAudit('create', type, record?.id, values, `${type} created`);
      setModalType(null);
      setNotice({ type: 'success', text: `${type[0].toUpperCase()}${type.slice(1)} created successfully.` });
      await hydrate(session.user.id);
    } catch (error) {
      console.error('record create failed', error);
      setNotice({ type: 'error', text: friendlyError });
    }
  }

  async function handleFollowUpComplete(record) {
    try {
      await updateRecord('follow_ups', record.id, { status: 'completed' });
      await writeAudit('update', 'FollowUp', record.id, { status: 'completed' }, 'Follow-up completed');
      await hydrate(session.user.id);
    } catch (error) {
      console.error('follow-up update failed', error);
      setNotice({ type: 'error', text: friendlyError });
    }
  }

  if (authLoading) return <div className="auth-loading"><div className="brand-mark">A</div><span>Loading AcxiomCRM...</span></div>;
  if (!session || !profile) return <AuthScreen notice={notice} setNotice={setNotice} />;

  const pageDescription = {
    Dashboard: 'Here’s what is happening across your sales workspace.', Customers: 'Manage relationships, contact details, and account health.', Leads: 'Qualify new opportunities and keep every conversation moving.', Opportunities: 'Track deal momentum from qualification through close.', 'Follow-ups': 'Stay ahead of every scheduled customer touchpoint.', Activities: 'A shared timeline of calls, meetings, emails, and tasks.', Reports: 'Understand conversion, pipeline coverage, and team performance.', 'Users & Roles': 'Control access, ownership, and account status.', 'Audit Log': 'Review security and business activity across the workspace.',
  }[activePage];

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
      <div className="brand-row"><div className="brand-mark">A</div><div><div className="brand-name">Acxiom<span>CRM</span></div><div className="brand-caption">Revenue workspace</div></div><button className="icon-button sidebar-close" onClick={() => setMobileOpen(false)} aria-label="Close navigation"><X size={18} /></button></div>
      <div className="workspace-switcher"><div className="workspace-icon">AC</div><div className="workspace-copy"><strong>Acxiom Corp.</strong><span>Sales workspace</span></div><ChevronDown size={15} /></div>
      <nav className="nav-section" aria-label="Main navigation"><div className="nav-label">Workspace</div>{navItems.map(({ label, icon: Icon }) => <button key={label} className={`nav-item ${activePage === label ? 'active' : ''}`} onClick={() => { setActivePage(label); setMobileOpen(false); }}><Icon size={18} strokeWidth={1.8} /><span>{label}</span>{label === 'Follow-ups' && <span className="nav-count">{workspace.follow_ups.filter((item) => item.status === 'planned').length}</span>}</button>)}<div className="nav-label admin-label">Administration</div>{adminItems.map(({ label, icon: Icon }) => <button key={label} className={`nav-item ${activePage === label ? 'active' : ''}`} onClick={() => { setActivePage(label); setMobileOpen(false); }}><Icon size={18} strokeWidth={1.8} /><span>{label}</span></button>)}</nav>
      <div className="sidebar-footer"><button className="nav-item"><Settings size={18} strokeWidth={1.8} /><span>Settings</span></button><div className="user-card"><div className="avatar avatar-navy">{initials(profile.full_name)}</div><div className="user-copy"><strong>{profile.full_name}</strong><span>{roleLabel(profile.role)}</span></div><button className="icon-button" onClick={handleSignOut} aria-label="Sign out"><LogOut size={16} /></button></div></div>
    </aside>
    <main className="main-content">
      <header className="topbar"><button className="icon-button mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu size={21} /></button><div className="breadcrumbs"><span>Workspace</span><span className="crumb-divider">/</span><strong>{activePage}</strong></div><div className="topbar-actions"><button className="icon-button notification-button" aria-label="Notifications"><Bell size={19} /><span className="notification-dot" /></button><div className="topbar-avatar">{initials(profile.full_name)}</div></div></header>
      <div className="content-wrap"><section className="page-heading"><div><div className="eyebrow">Thursday, October 8, 2026</div><h1>{activePage === 'Dashboard' ? `Good morning, ${profile.full_name.split(' ')[0]}` : activePage}</h1><p>{pageDescription}</p></div><div className="heading-actions"><div className="role-pill"><ShieldCheck size={15} /> {roleLabel(profile.role)}</div>{canCreatePage(activePage) && <button className="button button-primary" onClick={() => setModalType(modalForPage(activePage))}><Plus size={17} /> {actionLabel(activePage)}</button>}</div></section>
        {notice && <div className={`notice ${notice.type}`}><span>{notice.text}</span><button onClick={() => setNotice(null)} aria-label="Dismiss notification"><X size={15} /></button></div>}
        {loading && <div className="loading-line">Refreshing workspace data...</div>}
        {activePage === 'Dashboard' ? <Dashboard workspace={workspace} period={period} setPeriod={setPeriod} onComplete={handleFollowUpComplete} onCreate={() => setModalType('activity')} /> : activePage === 'Reports' ? <ReportsPage workspace={workspace} /> : <ModulePage page={activePage} workspace={workspace} onCreate={() => setModalType(modalForPage(activePage))} onComplete={handleFollowUpComplete} />}
      </div>
    </main>
    {modalType && <CreateModal type={modalType} onClose={() => setModalType(null)} onSubmit={handleCreate} />}
  </div>;
}

function AuthScreen({ notice, setNotice }) {
  const [mode, setMode] = useState('login');
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ fullName: '', email: '', password: '' });
  async function submit(event) {
    event.preventDefault();
    if (form.password.length < 8) { setNotice({ type: 'error', text: 'Use a password with at least 8 characters.' }); return; }
    try {
      setBusy(true);
      const result = mode === 'login' ? await supabase.auth.signInWithPassword({ email: form.email, password: form.password }) : await supabase.auth.signUp({ email: form.email, password: form.password, options: { data: { full_name: form.fullName } } });
      if (result.error) throw result.error;
      if (mode === 'signup' && !result.data.session) setNotice({ type: 'success', text: 'Your account was created. Check your email to finish signing in.' });
    } catch (error) {
      console.error('authentication failed', error);
      setNotice({ type: 'error', text: 'We could not sign you in with those details.' });
    } finally { setBusy(false); }
  }
  return <div className="auth-shell"><div className="auth-visual"><div className="auth-visual-inner"><div className="brand-row auth-brand"><div className="brand-mark">A</div><div className="brand-name">Acxiom<span>CRM</span></div></div><div className="auth-quote"><span>THE REVENUE OPERATING SYSTEM</span><h1>Turn every relationship into momentum.</h1><p>One calm, connected workspace for customers, leads, opportunities, and the people who move them forward.</p></div><div className="auth-stat-row"><div><strong>86%</strong><span>win rate on qualified deals</span></div><div><strong>2.8x</strong><span>faster follow-up response</span></div></div></div></div><div className="auth-panel"><div className="auth-form-wrap"><div className="mobile-auth-brand"><div className="brand-mark">A</div><div className="brand-name">Acxiom<span>CRM</span></div></div><div className="auth-kicker">{mode === 'login' ? 'WELCOME BACK' : 'GET STARTED'}</div><h2>{mode === 'login' ? 'Sign in to your workspace' : 'Create your workspace account'}</h2><p className="auth-subtitle">{mode === 'login' ? 'Pick up where your team left off.' : 'Your first account starts as an administrator.'}</p>{notice && <div className={`notice ${notice.type}`}>{notice.text}</div>}<form onSubmit={submit} className="auth-form">{mode === 'signup' && <label>Full name<input required value={form.fullName} onChange={(event) => setForm({ ...form, fullName: event.target.value })} placeholder="Jordan Davis" /></label>}<label>Email address<input required type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} placeholder="you@company.com" /></label><label>Password<input required type="password" minLength="8" value={form.password} onChange={(event) => setForm({ ...form, password: event.target.value })} placeholder="At least 8 characters" /></label><button className="button button-primary auth-submit" disabled={busy}>{busy ? 'Please wait...' : mode === 'login' ? 'Sign in' : 'Create account'} <ArrowUpRight size={16} /></button></form><button className="auth-switch" onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setNotice(null); }}>{mode === 'login' ? 'Need an account? Create one' : 'Already have an account? Sign in'}</button><div className="auth-footer"><ShieldCheck size={14} /> Protected workspace access</div></div></div></div>;
}

function Dashboard({ workspace, period, setPeriod, onComplete, onCreate }) {
  const totalPipeline = workspace.opportunities.filter((item) => !['won', 'lost'].includes(item.stage)).reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const openLeads = workspace.leads.filter((item) => !['converted', 'lost', 'unqualified'].includes(item.status)).length;
  const openOpportunities = workspace.opportunities.filter((item) => !['won', 'lost'].includes(item.stage)).length;
  const won = workspace.opportunities.filter((item) => item.stage === 'won').length;
  const kpis = [{ label: 'Total customers', value: workspace.customers.length, change: 'live', positive: true, icon: ContactRound, tone: 'blue' }, { label: 'Open leads', value: openLeads, change: 'live', positive: true, icon: Target, tone: 'amber' }, { label: 'Open opportunities', value: openOpportunities, change: 'live', positive: true, icon: CircleDollarSign, tone: 'green' }, { label: 'Pipeline value', value: money(totalPipeline), change: `${won} won`, positive: true, icon: ArrowUpRight, tone: 'slate' }];
  const upcoming = workspace.follow_ups.filter((item) => item.status === 'planned').slice(0, 4);
  const activities = workspace.activities.slice(0, 4);
  return <><section className="kpi-grid">{kpis.map(({ label, value, change, positive, icon: Icon, tone }) => <article className="kpi-card" key={label}><div className="kpi-topline"><span>{label}</span><div className={`kpi-icon ${tone}`}><Icon size={18} /></div></div><div className="kpi-value">{value}</div><div className={`kpi-change ${positive ? 'positive' : 'negative'}`}><ArrowUpRight size={14} /> {change}<span>authorized data</span></div></article>)}</section><section className="dashboard-grid"><Pipeline opportunities={workspace.opportunities} /><LeadChart leads={workspace.leads} period={period} setPeriod={setPeriod} /></section><section className="lower-grid"><FollowUps items={upcoming} onComplete={onComplete} onCreate={onCreate} /><RecentActivity items={activities} /></section></>;
}

function Pipeline({ opportunities }) {
  const stages = ['qualification', 'proposal', 'negotiation', 'won'];
  const colors = { qualification: '#2864dc', proposal: '#0c9b83', negotiation: '#e79a2f', won: '#46a66c' };
  const values = stages.map((stage) => ({ stage, amount: opportunities.filter((item) => item.stage === stage).reduce((sum, item) => sum + Number(item.amount || 0), 0), deals: opportunities.filter((item) => item.stage === stage).length }));
  const max = Math.max(...values.map((item) => item.amount), 1);
  return <article className="panel pipeline-panel"><div className="panel-header"><div><h2>Sales pipeline</h2><p>Weighted value by opportunity stage</p></div><span className="data-badge">Live</span></div><div className="pipeline-total"><strong>{money(values.reduce((sum, item) => sum + item.amount, 0))}</strong><span>total open pipeline</span></div><div className="pipeline-bars">{values.map((item) => <div className="pipeline-row" key={item.stage}><div className="pipeline-row-head"><span><i style={{ background: colors[item.stage] }} />{titleCase(item.stage)}</span><span>{money(item.amount)} <small>{item.deals} deals</small></span></div><div className="bar-track"><div className="bar-fill" style={{ width: `${Math.max(item.amount / max * 100, item.amount ? 8 : 0)}%`, background: colors[item.stage] }} /></div></div>)}</div></article>;
}

function LeadChart({ leads, period, setPeriod }) {
  const counts = ['new', 'contacted', 'qualified', 'converted', 'lost'].map((status) => ({ status, count: leads.filter((lead) => lead.status === status).length }));
  const max = Math.max(...counts.map((item) => item.count), 1);
  return <article className="panel chart-panel"><div className="panel-header"><div><h2>Lead performance</h2><p>Current authorized lead status</p></div><select value={period} onChange={(event) => setPeriod(event.target.value)} className="select-control"><option>This month</option><option>Last month</option><option>This quarter</option></select></div><div className="status-chart">{counts.map((item) => <div className="status-bar" key={item.status}><div className="status-bar-value">{item.count}</div><div className="status-bar-track"><div style={{ height: `${item.count / max * 100}%` }} /></div><span>{titleCase(item.status)}</span></div>)}</div></article>;
}

function FollowUps({ items, onComplete, onCreate }) { return <article className="panel followup-panel"><div className="panel-header"><div><h2>Upcoming follow-ups</h2><p>Stay ahead of every customer touchpoint</p></div><button className="icon-button"><MoreHorizontal size={19} /></button></div><div className="followup-list">{items.length ? items.map((item) => <div className="followup-row" key={item.id}><button className="check-button" onClick={() => onComplete(item)} aria-label="Mark follow-up complete" /><div className="avatar avatar-blue">FU</div><div className="followup-copy"><strong>{item.remarks || titleCase(item.follow_up_type)}</strong><span>{formatDate(item.follow_up_date)} <i /> {titleCase(item.status)}</span></div></div>) : <EmptyState text="No upcoming follow-ups yet." />}</div><button className="panel-footer-button" onClick={onCreate}>Schedule follow-up <Plus size={15} /></button></article>; }
function RecentActivity({ items }) { return <article className="panel activity-panel"><div className="panel-header"><div><h2>Recent activity</h2><p>Latest changes in your workspace</p></div></div><div className="activity-list">{items.length ? items.map((item) => <div className="activity-row" key={item.id}><div className="activity-icon blue"><ClipboardList size={16} /></div><div className="activity-copy"><strong>{item.subject}</strong><span>{titleCase(item.activity_type)} · {titleCase(item.status)}</span></div><time>{formatDate(item.activity_date)}</time></div>) : <EmptyState text="Activities will appear here." />}</div></article>; }
function EmptyState({ text }) { return <div className="empty-state">{text}</div>; }

function ModulePage({ page, workspace, onCreate, onComplete }) {
  const records = workspace[pageKey(page)] || [];
  return <section className="module-layout"><div className="module-summary"><div className="summary-icon"><PageIcon page={page} /></div><div><strong>{records.length}</strong><span>{page === 'Users & Roles' ? 'visible users' : page === 'Audit Log' ? 'security events' : 'records in your scope'}</span></div></div><div className="module-toolbar"><div className="search-field"><Search size={17} /><input placeholder={`Search ${page.toLowerCase()}...`} /></div><button className="button button-quiet"><Filter size={16} /> Filter</button>{canCreatePage(page) && <button className="button button-primary" onClick={onCreate}><Plus size={17} /> {actionLabel(page)}</button>}</div><div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Name</th><th>Details</th><th>Owner / Date</th><th>Status</th><th /></tr></thead><tbody>{records.length ? records.slice(0, 20).map((record) => <RecordRow key={record.id} page={page} record={record} onComplete={onComplete} />) : <tr><td colSpan="5"><EmptyState text={`No ${page.toLowerCase()} in your scope yet.`} /></td></tr>}</tbody></table></div><div className="table-footer"><span>Showing {Math.min(records.length, 20)} of {records.length} records</span><div className="pagination"><button className="page-button active">1</button></div></div></div></section>;
}

function ReportsPage({ workspace }) {
  const pipeline = workspace.opportunities.reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const converted = workspace.leads.filter((item) => item.status === 'converted').length;
  const completed = workspace.follow_ups.filter((item) => item.status === 'completed').length;
  const reports = [['Customer report', `${workspace.customers.length} customer records`, 'Owner, status, and creation date'], ['Lead conversion', `${converted} converted leads`, 'Source, status, and outcome metrics'], ['Pipeline report', money(pipeline), 'Stage-wise opportunity value'], ['Follow-up report', `${completed} completed`, 'Planned, completed, missed, and overdue activity']];
  return <section className="report-grid">{reports.map(([title, value, detail]) => <article className="panel report-card" key={title}><div className="summary-icon"><FileBarChart size={21} /></div><div className="eyebrow">Authorized report</div><h2>{title}</h2><strong>{value}</strong><p>{detail}</p><button className="text-button">Open report <ArrowUpRight size={15} /></button></article>)}</section>;
}

function RecordRow({ page, record, onComplete }) {
  const name = record.full_name || record.customer_name || record.lead_name || record.opportunity_name || record.subject || record.remarks || record.action || titleCase(record.follow_up_type || record.activity_type || 'Record');
  const detail = record.role || record.entity_name || record.company_name || record.stage || record.source || formatDate(record.follow_up_date || record.activity_date || record.created_at);
  const status = record.is_active === false ? 'inactive' : record.result || record.status || record.stage || 'active';
  return <tr><td>{name}</td><td>{detail}</td><td>{record.amount ? money(record.amount) : record.user_id ? formatDate(record.created_at) : formatDate(record.created_at)}</td><td className="status-cell"><span className={`status status-${String(status).replace('_', '-')}`}>{titleCase(status)}</span></td><td>{page === 'Follow-ups' && status === 'planned' ? <button className="table-action" onClick={() => onComplete(record)}>Complete</button> : <button className="icon-button"><MoreHorizontal size={18} /></button>}</td></tr>;
}

function CreateModal({ type, onClose, onSubmit }) {
  const [error, setError] = useState('');
  function submit(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const values = Object.fromEntries(form.entries());
    const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 1);
    if (type === 'opportunity' && (Number(values.amount) <= 0 || Number(values.probability) < 0 || Number(values.probability) > 100)) { setError('Amount must be greater than 0 and probability must be between 0 and 100.'); return; }
    if (type === 'follow-up' && new Date(values.follow_up_date) < tomorrow.setHours(0, 0, 0, 0)) { setError('New follow-ups cannot be scheduled in the past.'); return; }
    const payload = type === 'customer' ? { customer_code: `CUS-${Date.now().toString().slice(-6)}`, customer_name: values.customer_name, email: values.email, phone: values.phone, company_name: values.company_name } : type === 'lead' ? { lead_code: `LEAD-${Date.now().toString().slice(-6)}`, lead_name: values.lead_name, email: values.email, phone: values.phone, company_name: values.company_name, source: values.source, priority: values.priority, expected_value: Number(values.expected_value || 0) } : type === 'opportunity' ? { opportunity_name: values.opportunity_name, amount: Number(values.amount), probability: Number(values.probability), expected_close_date: values.expected_close_date, stage: values.stage, notes: values.notes } : type === 'follow-up' ? { follow_up_date: new Date(values.follow_up_date).toISOString(), follow_up_type: values.follow_up_type, remarks: values.remarks } : { activity_type: values.activity_type, subject: values.subject, description: values.description, activity_date: new Date(values.activity_date).toISOString() };
    onSubmit(type, payload);
  }
  const title = `${type[0].toUpperCase()}${type.slice(1)}`;
  return <div className="modal-backdrop" onClick={onClose}><div className="modal-card" onClick={(event) => event.stopPropagation()}><div className="modal-header"><div><div className="eyebrow">Create record</div><h2>New {title}</h2></div><button className="icon-button" onClick={onClose}><X size={19} /></button></div>{error && <div className="notice error">{error}</div>}<form onSubmit={submit} className="form-grid">{type === 'customer' && <><Field name="customer_name" label="Customer name" required /><Field name="company_name" label="Company" required /><Field name="email" label="Email" type="email" required /><Field name="phone" label="Phone" required /></>}{type === 'lead' && <><Field name="lead_name" label="Lead name" required /><Field name="company_name" label="Company" /><Field name="email" label="Email" type="email" required /><Field name="phone" label="Phone" required /><Field name="source" label="Source" required /><SelectField name="priority" label="Priority" options={['low', 'medium', 'high']} /></>}{type === 'opportunity' && <><Field name="opportunity_name" label="Opportunity name" required /><Field name="amount" label="Amount" type="number" min="0.01" step="0.01" required /><Field name="probability" label="Probability %" type="number" min="0" max="100" required /><Field name="expected_close_date" label="Expected close date" type="date" required /><SelectField name="stage" label="Stage" options={['qualification', 'proposal', 'negotiation', 'won', 'lost']} /><Field name="notes" label="Notes" /></>}{type === 'follow-up' && <><Field name="remarks" label="Subject" required /><SelectField name="follow_up_type" label="Type" options={['call', 'meeting', 'email', 'task']} /><Field name="follow_up_date" label="Date and time" type="datetime-local" required /></>}{type === 'activity' && <><Field name="subject" label="Subject" required /><SelectField name="activity_type" label="Type" options={['call', 'meeting', 'email', 'task']} /><Field name="activity_date" label="Date and time" type="datetime-local" required /><Field name="description" label="Notes" /></>}<div className="modal-footer full-field"><button type="button" className="button button-quiet" onClick={onClose}>Cancel</button><button className="button button-primary">Create {type}</button></div></form></div></div>;
}
function Field({ name, label, type = 'text', required = false, min, max, step }) { return <label>{label}<input name={name} type={type} required={required} min={min} max={max} step={step} /></label>; }
function SelectField({ name, label, options }) { return <label>{label}<select name={name} defaultValue={options[0]}>{options.map((option) => <option key={option} value={option}>{titleCase(option)}</option>)}</select></label>; }
function PageIcon({ page }) { const item = navItems.find((entry) => entry.label === page); const Icon = item?.icon || FileBarChart; return <Icon size={22} />; }
function modalForPage(page) { return ({ Customers: 'customer', Leads: 'lead', Opportunities: 'opportunity', 'Follow-ups': 'follow-up', Activities: 'activity' }[page] || 'activity'); }
function pageKey(page) { return ({ 'Users & Roles': 'profiles', Customers: 'customers', Leads: 'leads', Opportunities: 'opportunities', 'Follow-ups': 'follow_ups', Activities: 'activities', 'Audit Log': 'audit_logs' }[page]); }
function canCreatePage(page) { return ['Customers', 'Leads', 'Opportunities', 'Follow-ups', 'Activities'].includes(page); }
function actionLabel(page) { return ({ Customers: 'Add customer', Leads: 'Add lead', Opportunities: 'Add opportunity', 'Follow-ups': 'Schedule follow-up', Activities: 'Log activity', Reports: 'Create report' }[page] || 'New activity'); }
function roleLabel(role) { return ({ admin: 'Administrator', manager: 'Manager', sales_executive: 'Sales Executive' }[role] || 'User'); }
function initials(name) { return name.split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase(); }
function titleCase(value) { return String(value || '').replace(/_/g, ' ').replace(/\b\w/g, (letter) => letter.toUpperCase()); }
function money(value) { return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(Number(value || 0)); }
function formatDate(value) { return value ? new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(value)) : '—'; }

createRoot(document.getElementById('root')).render(<App />);
