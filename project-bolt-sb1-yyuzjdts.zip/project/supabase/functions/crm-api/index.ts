import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const tableByResource: Record<string, string> = {
  customers: 'customers',
  leads: 'leads',
  opportunities: 'opportunities',
  followups: 'follow_ups',
};

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
}

Deno.serve(async (request: Request) => {
  if (request.method === 'OPTIONS') return new Response(null, { status: 200, headers: corsHeaders });
  try {
    const authorization = request.headers.get('Authorization');
    if (!authorization?.startsWith('Bearer ')) return response({ error: 'Authentication required.' }, 401);
    const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_ANON_KEY') ?? '', { global: { headers: { Authorization: authorization } } });
    const url = new URL(request.url);
    const segments = url.pathname.split('/').filter(Boolean);
    const resource = segments.at(-1) ?? '';
    const id = segments.at(-2) && segments.at(-2) !== 'crm-api' ? segments.at(-1) : null;
    const table = tableByResource[resource] ?? (segments.at(-2) ? tableByResource[segments.at(-2)] : null);

    if (resource === 'pipeline') {
      const { data, error } = await supabase.from('opportunities').select('stage, amount, probability, owner_id');
      if (error) return response({ error: 'Could not load pipeline data.' }, 400);
      const totals = (data ?? []).reduce<Record<string, { amount: number; weighted_amount: number; deals: number }>>((result, item) => {
        const current = result[item.stage] ?? { amount: 0, weighted_amount: 0, deals: 0 };
        current.amount += Number(item.amount);
        current.weighted_amount += Number(item.amount) * Number(item.probability) / 100;
        current.deals += 1;
        result[item.stage] = current;
        return result;
      }, {});
      return response({ data: totals });
    }

    if (!table) return response({ error: 'Resource not found.' }, 404);
    if (request.method === 'GET') {
      const query = supabase.from(table).select('*').order('created_at', { ascending: false }).limit(100);
      const { data, error } = await query;
      if (error) return response({ error: 'Could not load records.' }, 400);
      return response({ data: data ?? [] });
    }

    if (request.method === 'POST') {
      const payload = await request.json();
      if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return response({ error: 'Invalid request body.' }, 400);
      const { data, error } = await supabase.from(table).insert(payload).select().maybeSingle();
      if (error) return response({ error: 'Could not create record.' }, 400);
      return response({ data }, 201);
    }

    if (request.method === 'PUT' && id) {
      const payload = await request.json();
      if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return response({ error: 'Invalid request body.' }, 400);
      const { data, error } = await supabase.from(table).update(payload).eq('id', id).select().maybeSingle();
      if (error) return response({ error: 'Could not update record.' }, 400);
      if (!data) return response({ error: 'Record not found.' }, 404);
      return response({ data });
    }

    if (request.method === 'DELETE' && id) {
      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) return response({ error: 'Could not delete record.' }, 400);
      return response({ data: { id } });
    }

    return response({ error: 'Method not allowed.' }, 405);
  } catch (error) {
    console.error('crm api request failed', error);
    return response({ error: 'The request could not be completed.' }, 500);
  }
});
