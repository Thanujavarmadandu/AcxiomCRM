/*
# Remove public execution from AcxiomCRM security functions

1. Security change
- Revoke default PUBLIC and anonymous EXECUTE privileges from all SECURITY DEFINER helpers.
- Preserve authenticated execution only where the application needs it.
- Preserve trigger execution for the Auth profile creation function through its owning trigger.

2. Data safety
- This migration changes permissions only and does not alter or delete CRM data.
*/

REVOKE EXECUTE ON FUNCTION public.current_profile_role() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_crm_role(text[]) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_acxiom_user() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.write_audit_event(text, text, uuid, jsonb, jsonb, text, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.set_profile_role(uuid, text) FROM PUBLIC, anon;

GRANT EXECUTE ON FUNCTION public.current_profile_role() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_crm_role(text[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.write_audit_event(text, text, uuid, jsonb, jsonb, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_profile_role(uuid, text) TO authenticated;
