/*
# Create AcxiomCRM core CRM data model

1. New Tables
- `profiles`: authenticated user display name, role, active status, and lockout metadata.
- `customers`: customer accounts with contact information, status, owner, and creator.
- `leads`: prospect records with source, status, priority, expected value, and assignment.
- `opportunities`: sales opportunities with stage, amount, probability, close date, and ownership.
- `follow_ups`: scheduled customer or lead touchpoints with status and assignee.
- `activities`: calls, meetings, emails, and tasks linked to CRM records.
- `audit_logs`: append-oriented security and business event history.

2. Validation and integrity
- Customer and lead email/phone values are normalized on write by application validation and uniqueness indexes.
- Opportunity amount, probability, and close-date constraints enforce core business rules.
- Follow-up status and dates use constrained values.
- Ownership defaults come from the authenticated session where applicable.

3. Security
- Row level security is enabled on every table.
- Admins can manage all CRM records.
- Managers can access team CRM records but not security administration.
- Sales executives can access only records assigned to them or created by them.
- Profile roles are protected from normal client updates.
- Audit events are inserted through a server-enforced function that derives the actor from `auth.uid()`.

4. Authentication support
- A trigger creates a profile for each new Auth user.
- The first registered user receives the Admin role; later users receive Sales Executive by default.
*/

CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT 'Acxiom User',
  role text NOT NULL DEFAULT 'sales_executive' CHECK (role IN ('admin', 'manager', 'sales_executive')),
  is_active boolean NOT NULL DEFAULT true,
  failed_login_count integer NOT NULL DEFAULT 0 CHECK (failed_login_count >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_code text NOT NULL UNIQUE,
  customer_name text NOT NULL CHECK (char_length(customer_name) BETWEEN 2 AND 160),
  email text NOT NULL,
  phone text NOT NULL CHECK (char_length(phone) BETWEEN 7 AND 30),
  company_name text NOT NULL CHECK (char_length(company_name) BETWEEN 2 AND 160),
  address text,
  city text,
  state text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'at_risk', 'inactive')),
  owner_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  created_by uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_code text NOT NULL UNIQUE,
  lead_name text NOT NULL CHECK (char_length(lead_name) BETWEEN 2 AND 160),
  email text NOT NULL,
  phone text NOT NULL CHECK (char_length(phone) BETWEEN 7 AND 30),
  company_name text,
  source text NOT NULL CHECK (char_length(source) BETWEEN 2 AND 80),
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'qualified', 'unqualified', 'converted', 'lost')),
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
  expected_value numeric(14,2) NOT NULL DEFAULT 0 CHECK (expected_value >= 0),
  assigned_to uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  created_by uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  opportunity_name text NOT NULL CHECK (char_length(opportunity_name) BETWEEN 2 AND 160),
  customer_id uuid REFERENCES public.customers(id) ON DELETE SET NULL,
  lead_id uuid REFERENCES public.leads(id) ON DELETE SET NULL,
  stage text NOT NULL DEFAULT 'qualification' CHECK (stage IN ('qualification', 'proposal', 'negotiation', 'won', 'lost')),
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  probability integer NOT NULL DEFAULT 10 CHECK (probability BETWEEN 0 AND 100),
  expected_close_date date NOT NULL,
  source text,
  notes text,
  owner_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  created_by uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT active_opportunity_close_date CHECK (stage IN ('won', 'lost') OR expected_close_date >= CURRENT_DATE)
);

CREATE TABLE IF NOT EXISTS public.follow_ups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES public.customers(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES public.leads(id) ON DELETE CASCADE,
  follow_up_date timestamptz NOT NULL,
  follow_up_type text NOT NULL CHECK (follow_up_type IN ('call', 'meeting', 'email', 'task')),
  remarks text,
  status text NOT NULL DEFAULT 'planned' CHECK (status IN ('planned', 'completed', 'missed', 'cancelled')),
  assigned_to uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  created_by uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT follow_up_related_record CHECK (customer_id IS NOT NULL OR lead_id IS NOT NULL),
  CONSTRAINT planned_follow_up_date CHECK (status <> 'planned' OR follow_up_date >= now())
);

CREATE TABLE IF NOT EXISTS public.activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  activity_type text NOT NULL CHECK (activity_type IN ('call', 'meeting', 'email', 'task')),
  subject text NOT NULL CHECK (char_length(subject) BETWEEN 2 AND 160),
  description text,
  activity_date timestamptz NOT NULL DEFAULT now(),
  customer_id uuid REFERENCES public.customers(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES public.leads(id) ON DELETE CASCADE,
  assigned_to uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  status text NOT NULL DEFAULT 'completed' CHECK (status IN ('planned', 'completed', 'cancelled')),
  created_by uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT activity_related_record CHECK (customer_id IS NOT NULL OR lead_id IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES public.profiles(id),
  action text NOT NULL CHECK (action IN ('login', 'failed_login', 'logout', 'create', 'update', 'delete', 'role_change', 'security')),
  entity_name text NOT NULL,
  record_id uuid,
  old_value jsonb,
  new_value jsonb,
  result text NOT NULL DEFAULT 'success',
  details text,
  ip_address inet,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS customers_email_lower_key ON public.customers (lower(email));
CREATE UNIQUE INDEX IF NOT EXISTS customers_phone_key ON public.customers (phone);
CREATE INDEX IF NOT EXISTS customers_owner_idx ON public.customers (owner_id);
CREATE INDEX IF NOT EXISTS leads_assigned_to_idx ON public.leads (assigned_to);
CREATE INDEX IF NOT EXISTS leads_status_idx ON public.leads (status);
CREATE INDEX IF NOT EXISTS opportunities_owner_idx ON public.opportunities (owner_id);
CREATE INDEX IF NOT EXISTS opportunities_stage_idx ON public.opportunities (stage);
CREATE INDEX IF NOT EXISTS follow_ups_assigned_to_idx ON public.follow_ups (assigned_to);
CREATE INDEX IF NOT EXISTS follow_ups_date_idx ON public.follow_ups (follow_up_date);
CREATE INDEX IF NOT EXISTS activities_assigned_to_idx ON public.activities (assigned_to);
CREATE INDEX IF NOT EXISTS audit_logs_created_at_idx ON public.audit_logs (created_at DESC);

CREATE OR REPLACE FUNCTION public.current_profile_role()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid() AND is_active = true;
$$;

REVOKE ALL ON FUNCTION public.current_profile_role() FROM anon;
GRANT EXECUTE ON FUNCTION public.current_profile_role() TO authenticated;

CREATE OR REPLACE FUNCTION public.has_crm_role(required_roles text[])
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(public.current_profile_role() = ANY(required_roles), false);
$$;

REVOKE ALL ON FUNCTION public.has_crm_role(text[]) FROM anon;
GRANT EXECUTE ON FUNCTION public.has_crm_role(text[]) TO authenticated;

CREATE OR REPLACE FUNCTION public.handle_new_acxiom_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  assigned_role text;
BEGIN
  assigned_role := CASE WHEN NOT EXISTS (SELECT 1 FROM public.profiles) THEN 'admin' ELSE 'sales_executive' END;
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (NEW.id, COALESCE(NULLIF(NEW.raw_user_meta_data ->> 'full_name', ''), split_part(NEW.email, '@', 1)), assigned_role);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_acxiom_auth_user_created ON auth.users;
CREATE TRIGGER on_acxiom_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_acxiom_user();

CREATE OR REPLACE FUNCTION public.write_audit_event(
  p_action text,
  p_entity_name text,
  p_record_id uuid DEFAULT NULL,
  p_old_value jsonb DEFAULT NULL,
  p_new_value jsonb DEFAULT NULL,
  p_result text DEFAULT 'success',
  p_details text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  audit_id uuid;
BEGIN
  IF auth.uid() IS NULL OR public.current_profile_role() IS NULL THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  IF p_action NOT IN ('login', 'failed_login', 'logout', 'create', 'update', 'delete', 'role_change', 'security') THEN
    RAISE EXCEPTION 'Invalid audit action';
  END IF;
  INSERT INTO public.audit_logs (user_id, action, entity_name, record_id, old_value, new_value, result, details)
  VALUES (auth.uid(), p_action, p_entity_name, p_record_id, p_old_value, p_new_value, p_result, p_details)
  RETURNING id INTO audit_id;
  RETURN audit_id;
END;
$$;

REVOKE ALL ON FUNCTION public.write_audit_event(text, text, uuid, jsonb, jsonb, text, text) FROM anon;
GRANT EXECUTE ON FUNCTION public.write_audit_event(text, text, uuid, jsonb, jsonb, text, text) TO authenticated;

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.opportunities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follow_ups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_authenticated" ON public.profiles;
CREATE POLICY "profiles_select_authenticated" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid() OR public.has_crm_role(ARRAY['admin','manager']));
DROP POLICY IF EXISTS "profiles_update_self" ON public.profiles;
CREATE POLICY "profiles_update_self" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());

DROP POLICY IF EXISTS "customers_select_scope" ON public.customers;
CREATE POLICY "customers_select_scope" ON public.customers FOR SELECT TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']) OR owner_id = auth.uid() OR created_by = auth.uid());
DROP POLICY IF EXISTS "customers_insert_authenticated" ON public.customers;
CREATE POLICY "customers_insert_authenticated" ON public.customers FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND owner_id = auth.uid());
DROP POLICY IF EXISTS "customers_update_scope" ON public.customers;
CREATE POLICY "customers_update_scope" ON public.customers FOR UPDATE TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']) OR owner_id = auth.uid()) WITH CHECK (public.has_crm_role(ARRAY['admin','manager']) OR owner_id = auth.uid());
DROP POLICY IF EXISTS "customers_delete_admin_manager" ON public.customers;
CREATE POLICY "customers_delete_admin_manager" ON public.customers FOR DELETE TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']));

DROP POLICY IF EXISTS "leads_select_scope" ON public.leads;
CREATE POLICY "leads_select_scope" ON public.leads FOR SELECT TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']) OR assigned_to = auth.uid() OR created_by = auth.uid());
DROP POLICY IF EXISTS "leads_insert_authenticated" ON public.leads;
CREATE POLICY "leads_insert_authenticated" ON public.leads FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND assigned_to = auth.uid());
DROP POLICY IF EXISTS "leads_update_scope" ON public.leads;
CREATE POLICY "leads_update_scope" ON public.leads FOR UPDATE TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']) OR assigned_to = auth.uid()) WITH CHECK (public.has_crm_role(ARRAY['admin','manager']) OR assigned_to = auth.uid());
DROP POLICY IF EXISTS "leads_delete_admin_manager" ON public.leads;
CREATE POLICY "leads_delete_admin_manager" ON public.leads FOR DELETE TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']));

DROP POLICY IF EXISTS "opportunities_select_scope" ON public.opportunities;
CREATE POLICY "opportunities_select_scope" ON public.opportunities FOR SELECT TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']) OR owner_id = auth.uid() OR created_by = auth.uid());
DROP POLICY IF EXISTS "opportunities_insert_authenticated" ON public.opportunities;
CREATE POLICY "opportunities_insert_authenticated" ON public.opportunities FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND owner_id = auth.uid());
DROP POLICY IF EXISTS "opportunities_update_scope" ON public.opportunities;
CREATE POLICY "opportunities_update_scope" ON public.opportunities FOR UPDATE TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']) OR owner_id = auth.uid()) WITH CHECK (public.has_crm_role(ARRAY['admin','manager']) OR owner_id = auth.uid());
DROP POLICY IF EXISTS "opportunities_delete_admin_manager" ON public.opportunities;
CREATE POLICY "opportunities_delete_admin_manager" ON public.opportunities FOR DELETE TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']));

DROP POLICY IF EXISTS "follow_ups_select_scope" ON public.follow_ups;
CREATE POLICY "follow_ups_select_scope" ON public.follow_ups FOR SELECT TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']) OR assigned_to = auth.uid() OR created_by = auth.uid());
DROP POLICY IF EXISTS "follow_ups_insert_authenticated" ON public.follow_ups;
CREATE POLICY "follow_ups_insert_authenticated" ON public.follow_ups FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND assigned_to = auth.uid());
DROP POLICY IF EXISTS "follow_ups_update_scope" ON public.follow_ups;
CREATE POLICY "follow_ups_update_scope" ON public.follow_ups FOR UPDATE TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']) OR assigned_to = auth.uid()) WITH CHECK (public.has_crm_role(ARRAY['admin','manager']) OR assigned_to = auth.uid());
DROP POLICY IF EXISTS "follow_ups_delete_admin_manager" ON public.follow_ups;
CREATE POLICY "follow_ups_delete_admin_manager" ON public.follow_ups FOR DELETE TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']));

DROP POLICY IF EXISTS "activities_select_scope" ON public.activities;
CREATE POLICY "activities_select_scope" ON public.activities FOR SELECT TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']) OR assigned_to = auth.uid() OR created_by = auth.uid());
DROP POLICY IF EXISTS "activities_insert_authenticated" ON public.activities;
CREATE POLICY "activities_insert_authenticated" ON public.activities FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND assigned_to = auth.uid());
DROP POLICY IF EXISTS "activities_update_scope" ON public.activities;
CREATE POLICY "activities_update_scope" ON public.activities FOR UPDATE TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']) OR assigned_to = auth.uid()) WITH CHECK (public.has_crm_role(ARRAY['admin','manager']) OR assigned_to = auth.uid());
DROP POLICY IF EXISTS "activities_delete_admin_manager" ON public.activities;
CREATE POLICY "activities_delete_admin_manager" ON public.activities FOR DELETE TO authenticated USING (public.has_crm_role(ARRAY['admin','manager']));

DROP POLICY IF EXISTS "audit_logs_select_admin" ON public.audit_logs;
CREATE POLICY "audit_logs_select_admin" ON public.audit_logs FOR SELECT TO authenticated USING (public.has_crm_role(ARRAY['admin']));
DROP POLICY IF EXISTS "audit_logs_insert_function_only" ON public.audit_logs;
CREATE POLICY "audit_logs_insert_function_only" ON public.audit_logs FOR INSERT TO authenticated WITH CHECK (false);
DROP POLICY IF EXISTS "audit_logs_update_denied" ON public.audit_logs;
CREATE POLICY "audit_logs_update_denied" ON public.audit_logs FOR UPDATE TO authenticated USING (false) WITH CHECK (false);
DROP POLICY IF EXISTS "audit_logs_delete_denied" ON public.audit_logs;
CREATE POLICY "audit_logs_delete_denied" ON public.audit_logs FOR DELETE TO authenticated USING (false);

REVOKE UPDATE ON public.profiles FROM authenticated;
GRANT UPDATE (full_name) ON public.profiles TO authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.audit_logs FROM authenticated;
