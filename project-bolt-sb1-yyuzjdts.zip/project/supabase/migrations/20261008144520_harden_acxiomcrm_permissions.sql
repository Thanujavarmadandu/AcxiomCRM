/*
# Harden AcxiomCRM permissions and role administration

1. Permission changes
- Remove anonymous access to all CRM tables and helper functions.
- Keep authenticated access limited by the existing row-level security policies.
- Keep audit log writes available only through the server-enforced audit function.

2. Privileged role administration
- Add `set_profile_role` for administrators to change a user's role.
- The function derives the acting administrator from `auth.uid()` and validates the target role.
- The function records the role change in the protected audit log.

3. Safety notes
- No data is deleted or altered by this migration.
- Normal users can still update their own display name but cannot change role or active status.
*/

REVOKE ALL ON public.profiles FROM anon;
REVOKE ALL ON public.customers FROM anon;
REVOKE ALL ON public.leads FROM anon;
REVOKE ALL ON public.opportunities FROM anon;
REVOKE ALL ON public.follow_ups FROM anon;
REVOKE ALL ON public.activities FROM anon;
REVOKE ALL ON public.audit_logs FROM anon;

REVOKE ALL ON FUNCTION public.current_profile_role() FROM anon;
REVOKE ALL ON FUNCTION public.has_crm_role(text[]) FROM anon;
REVOKE ALL ON FUNCTION public.handle_new_acxiom_user() FROM anon;
REVOKE ALL ON FUNCTION public.write_audit_event(text, text, uuid, jsonb, jsonb, text, text) FROM anon;

CREATE OR REPLACE FUNCTION public.set_profile_role(p_user_id uuid, p_role text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  previous_role text;
BEGIN
  IF public.current_profile_role() <> 'admin' THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  IF p_role NOT IN ('admin', 'manager', 'sales_executive') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;
  SELECT role INTO previous_role FROM public.profiles WHERE id = p_user_id;
  IF previous_role IS NULL THEN
    RAISE EXCEPTION 'Profile not found';
  END IF;
  UPDATE public.profiles SET role = p_role, updated_at = now() WHERE id = p_user_id;
  INSERT INTO public.audit_logs (user_id, action, entity_name, record_id, old_value, new_value, details)
  VALUES (auth.uid(), 'role_change', 'Profile', p_user_id, jsonb_build_object('role', previous_role), jsonb_build_object('role', p_role), 'Administrator changed user role');
END;
$$;

REVOKE ALL ON FUNCTION public.set_profile_role(uuid, text) FROM anon;
GRANT EXECUTE ON FUNCTION public.set_profile_role(uuid, text) TO authenticated;
